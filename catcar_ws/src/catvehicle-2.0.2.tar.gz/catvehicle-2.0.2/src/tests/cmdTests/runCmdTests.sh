#!/bin/bash

./cmdSimpleTest.sh

./cmdTireTest.sh

./cmdVelTest.sh


