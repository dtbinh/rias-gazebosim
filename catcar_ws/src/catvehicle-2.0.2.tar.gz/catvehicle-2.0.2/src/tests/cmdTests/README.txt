Author: Jonathan Sprinkle

This tests directory contains tests that command the simulated car in 
Gazebo using only commands to the low-level joints and transmissions on
the simulated car.

The tests will run ONLY when the cmdvel2gazebo.py node is not running.
